window.onload = setup;

function setup(){
	var button = document.getElementById("makeGreen");
	button.onclick = makeGreen;

}

function makeGreen(){
	var heading = document.getElementById("firstHeading");
	heading.style.color = "green";
}