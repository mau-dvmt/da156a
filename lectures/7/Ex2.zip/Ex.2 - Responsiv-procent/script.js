 window.onload = start;
 
 function start(){
	 var menyBtn = document.querySelector("#showHideMenu");
	 menyBtn.onclick = showHideMenu;
 }
 
 function showHideMenu(){
	 var menu = document.querySelector("#menu");
	 if(menu.className == "hide"){
		 menu.className = "show";
	 }else{
		 menu.className = "hide";
	 }
 }