/*
	Detta script välkomnar användaren, och frågar efter namnet.
*/
// Välkomnar användaren genom en popup-ruta
alert("Hej och välkommen till min webbsida! =)"); 

// Frågar användaren efter namn, och sparar det i variabeln "name"
var name = prompt("Vad heter du?"); 

// Meddelar användaren om att namnet är fint
alert("Hej " + name + "! Vilket fint namn!");

 