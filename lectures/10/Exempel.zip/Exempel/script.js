window.onload = start;

function start(){
	$("#saveItem").on("click", saveItem);
	$("#the-list").on("click", ".remove-item", removeItem);
}

function saveItem(){
	var item = $("#item").val();
	$("#the-list").append("<li>"+item+'<button class="remove-item btn btn-danger">X</button></li>')
}

function removeItem(){
	$(this).parent().remove();
}